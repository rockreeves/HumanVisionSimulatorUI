using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// [ExecuteAlways]
public class OpenDepthMode : MonoBehaviour
{
    private Material mat;
    public Shader shader;
    public Camera mCam;
    void Start()
    {
        Camera.main.depthTextureMode |= DepthTextureMode.Depth;
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (mat == null)
        {
            mat = new Material(shader);
        }
        if (mat != null)
        {
            Graphics.Blit(source, destination, mat);
        }
    }
}

